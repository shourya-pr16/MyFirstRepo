package com.oodb.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OodbDemoProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(OodbDemoProjectApplication.class, args);
	}

}
