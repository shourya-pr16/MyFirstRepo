package com.oodb.demo.entity;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;
import java.util.Set;

@NoArgsConstructor
@Data
@Entity
@Table
public class Student {

    @Id
//    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "studentId")
    private int studentId;
    @Column(name = "firstName")
    private String firstName;
    @Column(name = "lastName")
    private String lastName;
    @Embedded
    private Address address;
    @Column(name = "contactNumber")
    private String contactNumber;
    @Column(name = "emailId")
    private String emailId;
    @OneToOne
    private Course courseEnrolled;
    @Column(name = "dateOfBirth")
    @Temporal(TemporalType.DATE)
    private Date dateOfBirth;
    @Column(name = "enrollmentDate")
    @Temporal(TemporalType.DATE)
    private Date enrollmentDate;
}
