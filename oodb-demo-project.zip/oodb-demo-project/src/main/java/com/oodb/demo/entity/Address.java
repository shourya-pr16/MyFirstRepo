package com.oodb.demo.entity;

import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@NoArgsConstructor
@Embeddable
public class Address {
    @Column(name = "houseNumber")
    private String houseNumber;
    @Column(name = "street")
    private String street;
    @Column(name = "area")
    private String area;
    @Column(name = "zipCode")
    private String zipCode;
}
