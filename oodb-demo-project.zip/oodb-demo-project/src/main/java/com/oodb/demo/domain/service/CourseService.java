package com.oodb.demo.domain.service;

import com.oodb.demo.entity.Course;
import com.oodb.demo.entity.Subject;
import com.oodb.demo.repository.CourseRepository;
import com.oodb.demo.repository.SubjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class CourseService {

    @Autowired
    private CourseRepository courseRepository;
    @Autowired
    private SubjectRepository subjectRepository;

    public List<Course> updateCourseTables(List<Course> courseList) {
        List<Subject> subjectList = subjectRepository.findAll();

        Course course;
        Subject subject;
        for (int i = 0; i < subjectList.size(); i++) {
            course = courseList.get(i);
            int secondSubject = i == 0 ? subjectList.size()-1 : i - 1;

            Set<Subject> subjectSet = new HashSet<>(Arrays.asList(subjectList.get(i), subjectList.get(secondSubject)));
            course.setSubject(subjectSet);
//            subject = subjectList.get(i);
//            subject.setCourse(course);
        }
//        subjectRepository.saveAll(subjectList);
        return courseRepository.saveAll(courseList);
    }
}