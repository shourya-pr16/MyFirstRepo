package com.oodb.demo.entity;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@NoArgsConstructor
@Data
@Entity
@Table
public class Teacher {
    @Id
//    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "teacher_Id")
    private int teacherId;
    @Column(name = "firstName")
    private String firstName;
    @Column(name = "lastName")
    private String lastName;
    @Column(name = "contactNumber")
    private String contactNumber;
    @Embedded
    private Address address;
    @OneToOne
    private Subject subjectTaught;
    @Column(name = "salary")
    private String salary;
    @Column(name = "title")
    private String title;
}
