package com.oodb.demo.entity;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Set;

@Data
@Entity
@Table
@NoArgsConstructor
public class Course {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "courseId")
    private int courseId;
    @Column(name = "courseName")
    private String courseName;
    @Column(name = "creditScore")
    private int creditScore;
    @Column(name = "duration")
    private String duration;
    @OneToMany
    @JoinColumn(nullable = true)
    private Set<Subject> subject;

}
