package com.oodb.demo.entity;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
@NoArgsConstructor
@Data
@Entity
@Table
public class Subject {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "subjectId")
    private int subjectId;
    @Column(name = "subjectName")
    private String subjectName;
    @Column(name = "labRequired")
    private String labRequired;
    @Column(name = "minMarks")
    private int minMarks;
    @Column(name = "maxMarks")
    private int maxMarks;
    @ManyToOne
    private Course course;
}
