package com.oodb.demo.application;

import com.oodb.demo.domain.service.CourseService;
import com.oodb.demo.entity.Course;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/updateTable")
public class UpdateTablesController {

    @Autowired
    private CourseService courseService;

//    @GetMapping(path = "/updateCourse", produces = MediaType.APPLICATION_JSON_VALUE)
//    public List<Course> updateCourses(){
//        return courseService.updateCourseTables();
//    }
}
