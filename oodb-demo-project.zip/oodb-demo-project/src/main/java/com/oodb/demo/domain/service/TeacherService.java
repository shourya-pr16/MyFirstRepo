package com.oodb.demo.domain.service;

import com.oodb.demo.entity.Subject;
import com.oodb.demo.entity.Teacher;
import com.oodb.demo.repository.SubjectRepository;
import com.oodb.demo.repository.TeacherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeacherService {

    @Autowired
    private TeacherRepository teacherRepository;
    @Autowired
    private SubjectRepository subjectRepository;


    public List<Teacher> updateTeacherInfo(){
        List<Teacher> teachers = teacherRepository.findAll();
        List<Subject> subjects = subjectRepository.findAll();

        Teacher teacher;
        for (int i = 0; i < teachers.size(); i++) {
            teacher = teachers.get(i);
            teacher.setSubjectTaught(subjects.get(i));
        }
        return teacherRepository.saveAll(teachers);
    }
}
