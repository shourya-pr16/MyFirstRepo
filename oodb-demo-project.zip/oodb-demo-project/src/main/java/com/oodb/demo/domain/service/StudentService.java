package com.oodb.demo.domain.service;

import com.oodb.demo.entity.Course;
import com.oodb.demo.entity.Student;
import com.oodb.demo.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    public List<Student> updateStudentTable(List<Course> courses) {
        List<Student> students = studentRepository.findAll();
        Student student;
        for (int i = 0; i < students.size(); i++) {
            student = students.get(i);
            student.setCourseEnrolled(courses.get(i));
        }
        return studentRepository.saveAll(students);
    }
}
