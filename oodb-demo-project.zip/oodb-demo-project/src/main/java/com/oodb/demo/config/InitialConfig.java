package com.oodb.demo.config;

import com.oodb.demo.domain.service.CourseService;
import com.oodb.demo.domain.service.StudentService;
import com.oodb.demo.domain.service.TeacherService;
import com.oodb.demo.entity.Course;
import com.oodb.demo.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class InitialConfig {

    @Autowired
    private CourseService courseService;
    @Autowired
    private StudentService studentService;
    @Autowired
    private CourseRepository courseRepository;
    @Autowired
    private TeacherService teacherService;

    @Bean
    public String performInitialUpdates(){
        List<Course> courseList = courseRepository.findAll();
        List<Course> courses = courseService.updateCourseTables(courseList);
        studentService.updateStudentTable(courseList);
        teacherService.updateTeacherInfo();
        return courses.toString();
    }
}
